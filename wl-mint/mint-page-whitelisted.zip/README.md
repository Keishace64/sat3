# NFT Minting Site

Adapted by PerfectAlgo from: 
https://github.com/The-Stripes-NFT/nft-minting-app.git